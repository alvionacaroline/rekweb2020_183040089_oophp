<?php namespace App\Service;

class User {
	public function __construct() {
		echo "ini adalah class " . __CLASS__;
	}
}